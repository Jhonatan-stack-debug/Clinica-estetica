CLÍNICA AURORA — VERSÃO PARA GITHUB

Estrutura:
- index.html
- assets/ (imagens otimizadas)

Como subir:
1. Extraia o ZIP.
2. No GitHub, abra o repositório.
3. Clique em Add file > Upload files.
4. Arraste o index.html e a pasta assets.
5. Confirme o commit.

GitHub Pages:
Settings > Pages > Deploy from a branch > main / root.
